touch LRSO1.txt LRSO2.txt
for file in LRSO*.txt
do
   echo "$file"
done
