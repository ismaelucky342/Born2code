for i in {1..200..2}
do
   echo "$i"
done
